// /app/api/submit-form/route.ts
import { NextResponse } from "next/server"
import { Resend } from "resend"

const resend = new Resend(process.env.re_fLsM52fd_JComi8pVhFSP4r6QMfDxzFFu)

export async function POST(req: Request) {
  try {
    const data = await req.json()

    const { firstName, lastName, organization, title, email, phone } = data

    await resend.emails.send({
      from: "Acme <onboarding@resend.dev>",
      to: "olgagil@movement-health.org",
      subject: "New Event Registration",
      html: `
        <h2>New Registration</h2>
        <p><strong>Name:</strong> ${firstName} ${lastName}</p>
        <p><strong>Organization:</strong> ${organization}</p>
        <p><strong>Title:</strong> ${title}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Phone:</strong> ${phone}</p>
      `,
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("API Error:", error)
    return NextResponse.json({ success: false }, { status: 500 })
  }
}
