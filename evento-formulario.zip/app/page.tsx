import FormularioEvento from "@/formulario-evento"

export default function Home() {
  return (
    <main>
      <FormularioEvento />
    </main>
  )
}
